## Vehicles Monitoring System by Mini-Car

This work was developed with [Leonardo León](https://github.com/leo2105), [Renato Castro](https://github.com/renatocastro33) , Jose Navio and Marco Capcha.
